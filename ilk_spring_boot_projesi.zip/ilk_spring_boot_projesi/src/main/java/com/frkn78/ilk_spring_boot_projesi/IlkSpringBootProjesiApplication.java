package com.frkn78.ilk_spring_boot_projesi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IlkSpringBootProjesiApplication {

	public static void main(String[] args) {
		SpringApplication.run(IlkSpringBootProjesiApplication.class, args);
	}

}
