package com.frkn78.ilk_spring_boot_projesi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IlkSpringBootProjesiApplicationTests {

	@Test
	void contextLoads() {
	}

}
